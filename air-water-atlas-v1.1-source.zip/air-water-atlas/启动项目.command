#!/bin/zsh
set -e
cd -- "$(dirname -- "$0")"
RUNTIME_BIN="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin"
RUNTIME_FALLBACK="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback"
if ! command -v node >/dev/null 2>&1 && [[ -x "$RUNTIME_BIN/node" ]]; then
  export PATH="$RUNTIME_BIN:$RUNTIME_FALLBACK:$PATH"
fi
if ! command -v node >/dev/null 2>&1; then
  echo '请安装 Node.js 20.19+ 或 22.12+，然后重新启动。'
  read '?按回车退出'; exit 1
fi
if [[ ! -d node_modules/vite ]]; then
  if command -v pnpm >/dev/null 2>&1; then pnpm install
  elif command -v npm >/dev/null 2>&1; then npm install
  else echo '请先安装 pnpm 或 npm 并安装项目依赖。'; read '?按回车退出'; exit 1
  fi
fi
exec node node_modules/vite/bin/vite.js --host 0.0.0.0 --port 5173
