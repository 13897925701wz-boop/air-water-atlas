"""Reproducible NASA POWER ingestion. Python 3 stdlib only; no synthetic fallback."""
import calendar, csv, json, time, urllib.request, urllib.parse, concurrent.futures, datetime, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
POINTS=[('110000','北京','北京',116.40,39.90),('120000','天津','天津',117.20,39.12),('130000','河北','石家庄',114.51,38.04),('140000','山西','太原',112.55,37.87),('150000','内蒙古','呼和浩特',111.75,40.84),('210000','辽宁','沈阳',123.43,41.80),('220000','吉林','长春',125.32,43.90),('230000','黑龙江','哈尔滨',126.64,45.76),('310000','上海','上海',121.47,31.23),('320000','江苏','南京',118.80,32.06),('330000','浙江','杭州',120.16,30.27),('340000','安徽','合肥',117.23,31.82),('350000','福建','福州',119.30,26.08),('360000','江西','南昌',115.86,28.68),('370000','山东','济南',117.12,36.65),('410000','河南','郑州',113.63,34.75),('420000','湖北','武汉',114.31,30.59),('430000','湖南','长沙',112.94,28.23),('440000','广东','广州',113.26,23.13),('450000','广西','南宁',108.32,22.82),('460000','海南','海口',110.33,20.03),('500000','重庆','重庆',106.55,29.56),('510000','四川','成都',104.07,30.67),('520000','贵州','贵阳',106.63,26.65),('530000','云南','昆明',102.83,24.88),('540000','西藏','拉萨',91.14,29.65),('610000','陕西','西安',108.94,34.34),('620000','甘肃','兰州',103.83,36.06),('630000','青海','西宁',101.78,36.62),('640000','宁夏','银川',106.23,38.49),('650000','新疆','乌鲁木齐',87.62,43.83)]
CITIES=[('220100','长春市','长春',125.32,43.90),('220200','吉林市','吉林',126.55,43.84),('220300','四平市','四平',124.35,43.17),('220400','辽源市','辽源',125.14,42.90),('220500','通化市','通化',125.94,41.73),('220600','白山市','白山',126.42,41.94),('220700','松原市','松原',124.82,45.14),('220800','白城市','白城',122.84,45.62),('222400','延边朝鲜族自治州','延吉',129.51,42.90)]
FIELDS={'humidity':'RH2M','temperature':'T2M','solar':'ALLSKY_SFC_SW_DWN','precipitation':'PRECTOTCORR'}
def download(url,path):
    if path.exists(): return json.loads(path.read_text())
    for attempt in range(4):
        try:
            data=json.loads(subprocess.check_output(['curl','-fsSL','--max-time','70',url]))
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(json.dumps(data,ensure_ascii=False));return data
        except Exception:
            if attempt==3: raise
            time.sleep(2**attempt)
def fetch(point):
    code,name,city,lon,lat=point
    query=urllib.parse.urlencode(dict(parameters=','.join(FIELDS.values()),community='RE',longitude=lon,latitude=lat,format='JSON',start=2021,end=2025))
    url='https://power.larc.nasa.gov/api/temporal/monthly/point?'+query
    data=download(url,ROOT/'data/raw'/f'{code}.json')
    params=data['properties']['parameter'];fill=data.get('header',{}).get('fill_value',-999)
    months=[];raw=[]
    for month in range(1,13):
        item={'month':month}
        for field,key in FIELDS.items():
            values=[params[key].get(f'{year}{month:02}') for year in range(2021,2026)]
            if any(v is None or v==fill or not isinstance(v,(float,int)) for v in values):
                raise ValueError(f'{code}: missing {key} month {month}; refusing fabricated/interpolated data')
            item[field]=round(sum(values)/5,3)
        months.append(item)
    for year in range(2021,2026):
        for month in range(1,13):raw.append({'code':code,'name':name,'year':year,'month':month,**{field:params[key][f'{year}{month:02}'] for field,key in FIELDS.items()}})
    print(f'{code} {name}: 60 months verified',flush=True)
    return {'code':code,'name':name,'city':city,'lon':lon,'lat':lat,'months':months,'sourceUrl':url},raw
def main():
    (ROOT/'public/data').mkdir(parents=True,exist_ok=True)
    (ROOT/'public/maps').mkdir(parents=True,exist_ok=True)
    download('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json',ROOT/'public/maps/china.json')
    download('https://geo.datav.aliyun.com/areas_v3/bound/220000_full.json',ROOT/'public/maps/220000.json')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(fetch,POINTS+CITIES))
    document={'meta':{'source':'NASA POWER Monthly API','start':2021,'end':2025,'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'provinceCount':31,'cityProvince':'220000','cityCount':9,'sampleCount':2400,'droughtMethod':'precipitation proxy; NOT SPI or SPEI','aggregation':'Equal-weight monthly climatology over 2021–2025; annual score = mean of 12 monthly scores.','units':data_units()},'provinces':[r[0] for r in results[:31]],'cities':[r[0] for r in results[31:]]}
    target=ROOT/'public/data/climate.json';tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(document,ensure_ascii=False));tmp.replace(target)
    with (ROOT/'data/raw_climate.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=['code','name','year','month',*FIELDS]);writer.writeheader();writer.writerows([row for _,rows in results for row in rows])
    with (ROOT/'data/coord.csv').open('w') as f:
        writer=csv.writer(f);writer.writerow(['code','name','sampleCity','longitude','latitude']);writer.writerows(POINTS+CITIES)
    print('Saved verified dataset: 40 locations × 60 months.',flush=True)
def data_units():return {'humidity':'%','temperature':'°C','solar':'kWh/m²/day','precipitation':'mm/day'}
if __name__=='__main__':main()
