"""Create a single browser-openable HTML with embedded assets and authentic data."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist-offline'
OUTPUT=ROOT.parent/'凝水于空-双击打开.html'
html=(DIST/'index.html').read_text()
script_match=re.search(r'<script[^>]+src="([^"]+)"[^>]*></script>',html)
style_match=re.search(r'<link[^>]+href="([^"]+\.css)"[^>]*>',html)
if not script_match or not style_match:raise ValueError('Offline build did not produce a single JS/CSS bundle')
js=(DIST/script_match.group(1).lstrip('./')).read_text()
css=(DIST/style_match.group(1).lstrip('./')).read_text()
css=re.sub(r"@import\s+url\([^)]*fonts\.googleapis\.com[^)]*\);?",'',css)
# Allow safe embedding even if future data contains HTML-looking strings.
embed=lambda obj:json.dumps(obj,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
data=json.loads((ROOT/'public/data/climate.json').read_text())
maps={name:json.loads((ROOT/f'public/maps/{name}.json').read_text()) for name in ['china','220000']}
bootstrap=f'<script>window.__AIR_DATA__={embed(data)};window.__AIR_MAPS__={embed(maps)};</script>'
html=re.sub(r'<link[^>]+rel="icon"[^>]*>','',html)
html=html.replace('</head>',bootstrap+'</head>',1)
html=html.replace(style_match.group(0),f'<style>{css}</style>',1)
# Insert the JS last: report templates can themselves contain </head> or HTML tags.
# Rewriting the completed document would also rewrite those JavaScript strings.
safe_js=re.sub(r'</script',lambda m:'<\\/script',js,flags=re.IGNORECASE)
html=html.replace(script_match.group(0),f'<script type="module">{safe_js}</script>',1)
OUTPUT.write_text(html)
print(f'{OUTPUT} ({OUTPUT.stat().st_size:,} bytes)')
