"""Package the source and the ready-to-open offline edition without dependencies."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil

PROJECT = Path(__file__).resolve().parents[1]
WORKSPACE = PROJECT.parent
OUTPUT = WORKSPACE / '交付'
OUTPUT.mkdir(exist_ok=True)
HTML = WORKSPACE / '凝水于空-双击打开.html'
if not HTML.exists() or not (PROJECT / 'dist/index.html').exists():
    raise SystemExit('先运行生产构建、离线构建和 scripts/make_offline.py。')

standalone = OUTPUT / '凝水于空-v1.1-完善版.html'
shutil.copy2(HTML, standalone)
source_archive = OUTPUT / '凝水于空-v1.1-完整源码.zip'
ignored = {'node_modules', '.git', '.vite', 'dist-offline', '__pycache__'}
with ZipFile(source_archive, 'w', ZIP_DEFLATED) as archive:
    for file in sorted(PROJECT.rglob('*')):
        relative = file.relative_to(PROJECT)
        if file.is_file() and not ignored.intersection(relative.parts) and file.name != '.DS_Store':
            archive.write(file, Path('凝水于空-v1.1-源码') / relative)
    archive.write(HTML, '凝水于空-v1.1-源码/凝水于空-双击打开.html')

windows_archive = OUTPUT / '凝水于空-v1.1-Windows免安装版.zip'
with ZipFile(windows_archive, 'w', ZIP_DEFLATED) as archive:
    prefix = Path('凝水于空-v1.1')
    for file in sorted((PROJECT / 'dist').rglob('*')):
        if file.is_file() and file.name != '.DS_Store':
            archive.write(file, prefix / file.relative_to(PROJECT))
    for name in ['Start-Windows.bat', 'server-windows.ps1', 'Windows使用说明.txt']:
        archive.write(PROJECT / name, prefix / name)
    archive.write(HTML, prefix / '凝水于空-双击打开.html')

for archive_path in [source_archive, windows_archive]:
    with ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError(f'压缩包校验失败：{archive_path}')
for file in [standalone, source_archive, windows_archive]:
    print(f'{file} ({file.stat().st_size:,} bytes)')
