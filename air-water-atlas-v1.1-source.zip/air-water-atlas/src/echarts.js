import * as echarts from 'echarts/core';
import { MapChart, LineChart, BarChart, RadarChart, ScatterChart } from 'echarts/charts';
import { TooltipComponent, LegendComponent, GridComponent, VisualMapComponent, GeoComponent } from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';
echarts.use([MapChart,LineChart,BarChart,RadarChart,ScatterChart,TooltipComponent,LegendComponent,GridComponent,VisualMapComponent,GeoComponent,CanvasRenderer]);
export default echarts;
