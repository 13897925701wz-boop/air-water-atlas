<script setup>
import { onMounted, onBeforeUnmount, ref } from 'vue';
import { useAtlas } from './store';
import { Droplets, Map, ChartNoAxesCombined, SlidersHorizontal, Database, Layers, HelpCircle, Maximize2, Minimize2, X, ArrowRight, CheckCircle2 } from 'lucide-vue-next';
const store=useAtlas();
const guide=ref(),presenting=ref(false);
const nav=[['overview','潜力总览',Map],['province','省份详情',Layers],['compare','选址对比',ChartNoAxesCombined],['trend','季节趋势',ChartNoAxesCombined],['simulator','参数模拟',SlidersHorizontal],['data','数据溯源',Database]];
const steps=[
  ['选择目标与时段','在页面顶部切换综合推荐度、技术可行度或供能适宜性，再选择全年或单月。','overview'],
  ['探索地区条件','点击地图或搜索省份，查看气象画像和最佳月份；吉林支持九个市州下钻。','province'],
  ['进行选址对比','选取 2—5 个省份，比较评分、四项气象条件和月度窗口。','compare'],
  ['试验参数情景','选择预设或拖动滑块，对比当前参数与默认参数的评分、排名变化。','simulator'],
  ['带走分析结果','导出 CSV 或保存报告。报告包含当前区域、参数、评分和月度图，可打印成 PDF。','data'],
];
async function togglePresentation(){
  if(presenting.value){presenting.value=false;if(document.fullscreenElement)await document.exitFullscreen();return}
  presenting.value=true;
  try{await document.documentElement.requestFullscreen?.()}catch{}
}
function fullscreenChanged(){if(!document.fullscreenElement)presenting.value=false}
function escapePresentation(e){if(e.key==='Escape')presenting.value=false}
onMounted(()=>{store.load();document.addEventListener('fullscreenchange',fullscreenChanged);document.addEventListener('keydown',escapePresentation)});
onBeforeUnmount(()=>{document.removeEventListener('fullscreenchange',fullscreenChanged);document.removeEventListener('keydown',escapePresentation)});
</script>
<template>
  <div class="app-shell" :class="{'is-presenting':presenting}">
    <header class="topbar">
      <RouterLink to="/overview" class="brand"><span class="brand-symbol"><Droplets :size="25"/></span><span><strong>凝水于空<span class="brand-divider">/</span></strong><small>AIR WATER ATLAS</small></span></RouterLink>
      <nav aria-label="主导航"><RouterLink v-for="[path,label,icon] in nav" :key="path" :to="'/'+path"><component :is="icon" :size="17"/><span>{{label}}</span></RouterLink></nav>
      <div class="app-tools"><button @click="guide.showModal()" title="查看使用指南" aria-label="查看使用指南"><HelpCircle :size="17"/><span>使用指南</span></button><button @click="togglePresentation" :aria-pressed="presenting" :title="presenting?'退出演示模式':'进入演示模式'" :aria-label="presenting?'退出演示模式':'进入演示模式'"><Minimize2 v-if="presenting" :size="17"/><Maximize2 v-else :size="17"/><span>{{presenting?'退出演示':'演示模式'}}</span></button></div>
    </header>
    <main>
      <div v-if="store.loading" class="empty-state">正在读取 2021—2025 年气象数据…</div>
      <div v-else-if="store.error" class="empty-state"><h2>数据加载失败</h2><p>{{store.error}}</p><button @click="store.load">重新加载</button></div>
      <RouterView v-else-if="store.dataset"/>
    </main>
    <footer><span>凝水于空 · 中国空气取水潜力评估与选址可视化平台</span><span>NASA POWER / 2021—2025 <span class="foot-sep">·</span> 研究性模型 v1.1</span></footer>
    <dialog ref="guide" class="guide-dialog" aria-labelledby="guide-title">
      <div class="guide-heading"><div><span class="eyebrow">QUICK START</span><h2 id="guide-title">开始你的选址分析</h2></div><button @click="guide.close()" aria-label="关闭使用指南"><X :size="20"/></button></div>
      <p class="guide-intro">从真实气象数据出发，用五个步骤完成一次探索。月份、指标、所选省份和模型参数会在当前浏览器中记住。</p>
      <RouterLink v-for="([title,body,path],i) in steps" :key="path" :to="'/'+path" class="guide-step" @click="guide.close()"><span>{{String(i+1).padStart(2,'0')}}</span><div><h3>{{title}}</h3><p>{{body}}</p></div><ArrowRight :size="18"/></RouterLink>
      <div class="guide-footnote"><CheckCircle2 :size="17"/><span>双击打开版可离线查看全部页面。模型分值用于早期筛查，需结合场址调查和装置实验。</span></div>
    </dialog>
  </div>
</template>
