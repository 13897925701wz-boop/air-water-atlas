import { defineStore } from 'pinia';
import { computed, ref, reactive, watch } from 'vue';
import { defaults, evaluate } from './model';
import { presets, sanitizePreferences } from './assessment.js';
const storageKey='air-water-atlas:preferences:v1';
function readPreferences(){try{return sanitizePreferences(JSON.parse(localStorage.getItem(storageKey)))}catch{return sanitizePreferences(null)}}
export const useAtlas = defineStore('atlas', () => {
  const saved=readPreferences();
  const dataset = ref(null), error = ref(''), loading=ref(false);
  const weights = reactive(saved.weights);
  const metric = ref(saved.metric), month = ref(saved.month), selected = ref(saved.selected);
  const preset = computed(()=>presets.find(p=>Object.keys(defaults).every(k=>Math.abs(p.weights[k]-weights[k])<1e-8))?.id||'custom');
  const ranked = computed(() => (dataset.value?.provinces || []).map(p=>evaluate(p,weights,month.value)).sort((a,b)=>b[metric.value]-a[metric.value]));
  const modified = computed(()=>Object.keys(defaults).some(k=>weights[k]!==defaults[k]));
  async function load(){loading.value=true;error.value='';try{if(window.__AIR_DATA__){dataset.value=window.__AIR_DATA__}else{const r=await fetch('/data/climate.json');if(!r.ok)throw Error('数据文件未加载，请先运行采集脚本。');dataset.value=await r.json()}const codes=new Set(dataset.value.provinces.map(p=>p.code));selected.value=selected.value.filter(code=>codes.has(code))}catch(e){error.value=e.message}finally{loading.value=false}}
  function reset(){Object.assign(weights,defaults)}
  function applyPreset(id){const p=presets.find(p=>p.id===id);if(p)Object.assign(weights,p.weights)}
  watch(()=>({weights:{...weights},metric:metric.value,month:month.value,selected:[...selected.value]}),value=>{try{localStorage.setItem(storageKey,JSON.stringify(value))}catch{}},{deep:true});
  return {dataset,error,loading,weights,metric,month,selected,ranked,modified,preset,load,reset,applyPreset};
});
