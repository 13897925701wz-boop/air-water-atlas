export const defaults = Object.freeze({ humidityThreshold: 45, solarWeight: 1, droughtWeight: 0.35 });
export const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
// Exploratory, dimensionless suitability model, not calibrated water yield or ROI.
export function scoreMonth(m, weights = defaults) {
  const humidity = clamp((m.humidity - weights.humidityThreshold) / (85 - weights.humidityThreshold));
  const solar = clamp(m.solar / 6);
  const temperature = m.temperature <= 0 ? 0 : clamp(1 - Math.abs(m.temperature - 25) / 30);
  const drought = clamp(1 - m.precipitation / 5);
  const technical = 100 * humidity * temperature;
  const economic = technical * solar ** weights.solarWeight;
  const combined = economic * (1 + weights.droughtWeight * drought) / (1 + weights.droughtWeight);
  return { technical, economic, combined, humidity: humidity * 100, solar: solar * 100, temperature: temperature * 100, drought: drought * 100 };
}
export function evaluate(point, weights = defaults, month = 0) {
  const months = month ? point.months.filter(m => m.month === Number(month)) : point.months;
  const scores = months.map(m => scoreMonth(m, weights));
  const mean = key => scores.reduce((sum, s) => sum + s[key], 0) / scores.length;
  const climate = Object.fromEntries(['humidity','temperature','solar','precipitation'].map(k => [k, months.reduce((a,m)=>a+m[k],0)/months.length]));
  return {...point, climate, ...Object.fromEntries(Object.keys(scores[0]).map(k=>[k,mean(k)]))};
}
export const metricNames = {combined:'综合推荐度',technical:'技术可行度',economic:'供能适宜性'};
export const grade = n => n >= 40 ? '高潜力' : n >= 25 ? '较高潜力' : n >= 12 ? '中等潜力' : '低潜力';
