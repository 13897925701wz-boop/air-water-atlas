<script setup>
import { ref, watch, onMounted, computed } from 'vue';
import echarts from '../echarts';
import Chart from './Chart.vue';
import { metricNames } from '../model';
const props=defineProps({rows:Array,metric:String,region:{type:String,default:'china'}});const emit=defineEmits(['select']);const ready=ref(false),error=ref('');let request=0;
async function load(){const id=++request;ready.value=false;error.value='';try{if(!echarts.getMap(props.region)){let geo=window.__AIR_MAPS__?.[props.region];if(!geo){const r=await fetch(`/maps/${props.region}.json`);if(!r.ok)throw Error('地图暂不可用');geo=await r.json()}geo.features.forEach(f=>{f.properties.name=String(f.properties.adcode||f.properties.name)});echarts.registerMap(props.region,geo)}if(id===request)ready.value=true}catch(e){if(id===request)error.value=e.message}}
onMounted(load);watch(()=>props.region,load);
const option=computed(()=>({backgroundColor:'transparent',tooltip:{trigger:'item',backgroundColor:'#132c3b',borderColor:'#345260',textStyle:{color:'#e4f2f5'},formatter:p=>{const r=props.rows.find(r=>r.code===p.name);return r?`${r.name}<br/>${metricNames[props.metric]}：${r[props.metric].toFixed(1)} / 100<br/>${r.city}采样点 · 模型计算值`:'未纳入评估'}},visualMap:{min:0,max:100,left:22,bottom:12,itemWidth:8,itemHeight:110,orient:'horizontal',text:['100','0'],textStyle:{color:'#91a9b9'},inRange:{color:['#153447','#22536a','#258a98','#3bc4b4','#b4e9bb']},calculable:false},series:[{type:'map',map:props.region,roam:true,scaleLimit:{min:.8,max:4},zoom:1,layoutCenter:['49%','48%'],layoutSize:'90%',nameProperty:'name',itemStyle:{areaColor:'#152936',borderColor:'#50717c',borderWidth:.65},emphasis:{label:{show:true,color:'#fff',formatter:p=>props.rows.find(r=>r.code===p.name)?.name||''},itemStyle:{areaColor:'#d0ead2',borderColor:'#fff',borderWidth:1.5}},select:{disabled:true},data:props.rows.map(r=>({name:r.code,value:Number(r[props.metric].toFixed(2))}))}]}));
</script>
<template><Chart v-if="ready" :option="option" label="区域潜力分布地图，可点击区域查看详情" @select="p=>emit('select',p.name)"/><div v-else class="map-loading">{{error||'正在加载行政区地图…'}}<button v-if="error" @click="load">重试</button></div></template>
