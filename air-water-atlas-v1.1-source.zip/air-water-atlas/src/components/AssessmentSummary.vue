<script setup>
import { computed } from 'vue';
import { Sparkles, CalendarDays, Activity, ArrowUpRight } from 'lucide-vue-next';
import { describePoint } from '../assessment.js';
import { metricNames } from '../model.js';
const props=defineProps({point:Object,weights:Object,metric:String,month:Number,context:{type:String,default:'当前区域'}});
const insight=computed(()=>describePoint(props.point,props.weights,props.metric,props.month));
</script>
<template>
  <section class="assessment-summary" aria-label="当前分析结果解读">
    <div class="summary-intro"><span class="summary-eyebrow"><Sparkles :size="15"/>当前结果解读</span><h2>{{point.name}} <span>{{insight.grade}}</span></h2><p>{{context}} · {{metricNames[metric]}} {{insight.current[metric].toFixed(1)}} 分</p></div>
    <div class="summary-item"><CalendarDays :size="18"/><div><span>全年最佳月份</span><strong>{{insight.peak.month}} 月 <small>{{insight.peak.score.toFixed(1)}} 分</small></strong></div></div>
    <div class="summary-item"><Activity :size="18"/><div><span>较高以上评分窗口</span><strong>{{insight.favorable.length}} 个月</strong><p>{{insight.favorable.length?insight.favorable.join('、')+' 月':'暂无评分 ≥25 的月份'}}</p></div></div>
    <div class="summary-explanation"><span>相对较弱模型因子 · {{insight.limiting.label}}</span><p>{{insight.limiting.detail}}</p><RouterLink to="/data">评分口径 <ArrowUpRight :size="13"/></RouterLink></div>
  </section>
</template>
