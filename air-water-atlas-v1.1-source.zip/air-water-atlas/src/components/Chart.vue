<script setup>
import { onMounted, onBeforeUnmount, watch, ref } from 'vue';
import echarts from '../echarts';
const props=defineProps({option:Object,label:{type:String,default:'数据图表'}});const emit=defineEmits(['select']);const el=ref();let chart,observer;
onMounted(()=>{chart=echarts.init(el.value,null,{renderer:'canvas'});chart.setOption(props.option);chart.on('click',p=>emit('select',p));observer=new ResizeObserver(()=>chart.resize());observer.observe(el.value)});
watch(()=>props.option,v=>chart?.setOption(v,{notMerge:true}),{deep:true});
onBeforeUnmount(()=>{observer?.disconnect();chart?.dispose()});
</script>
<template><div ref="el" class="chart" role="img" :aria-label="label"></div></template>
