import { createApp } from 'vue';
import { createPinia } from 'pinia';
import { createRouter, createWebHistory, createWebHashHistory } from 'vue-router';
import App from './App.vue';
import Dashboard from './views/Dashboard.vue';
import './style.css';
const router=createRouter({history:location.protocol==='file:'?createWebHashHistory():createWebHistory(),routes:[{path:'/',redirect:'/overview'},...['overview','province','compare','trend','simulator','data'].map(path=>({path:`/${path}`,component:Dashboard})),{path:'/:pathMatch(.*)*',redirect:'/overview'}],scrollBehavior:()=>({top:0})});
createApp(App).use(createPinia()).use(router).mount('#app');
