import { defaults, evaluate, grade, metricNames, scoreMonth } from './model.js';

export const presets = Object.freeze([
  { id:'default', name:'默认研究参数', description:'湿度阈值 45%，平衡辐照与少雨权重。', weights:{...defaults} },
  { id:'inclusive', name:'放宽湿度条件', description:'降低湿度起效阈值，观察适宜区域如何扩展。', weights:{humidityThreshold:35,solarWeight:0.7,droughtWeight:0.35} },
  { id:'solar', name:'强调辐照供能', description:'加大对低辐照地区的评分折减。', weights:{humidityThreshold:45,solarWeight:1.6,droughtWeight:0.35} },
  { id:'dry', name:'强调少雨需求', description:'提高少雨地区的相对优先级。', weights:{humidityThreshold:45,solarWeight:1,droughtWeight:0.8} },
]);

export function sanitizePreferences(value) {
  const raw=value && typeof value==='object'?value:{};
  const result={metric:Object.hasOwn(metricNames,raw.metric)?raw.metric:'combined',month:Number.isInteger(raw.month)&&raw.month>=0&&raw.month<=12?raw.month:0,selected:Array.isArray(raw.selected)?[...new Set(raw.selected.filter(c=>typeof c==='string'&&/^\d{6}$/.test(c)))].slice(0,5):['220000','440000','530000'],weights:{...defaults}};
  for(const [key,min,max] of [['humidityThreshold',30,60],['solarWeight',0.2,2],['droughtWeight',0,1]]){
    const n=raw.weights?.[key];
    if(typeof n==='number'&&Number.isFinite(n))result.weights[key]=Math.max(min,Math.min(max,n));
  }
  return result;
}

export function describePoint(point,weights=defaults,metric='combined',month=0){
  const current=evaluate(point,weights,month);
  const months=point.months.map(m=>({month:m.month,score:scoreMonth(m,weights)[metric]}));
  const peak=months.reduce((a,b)=>b.score>a.score?b:a);
  const favorable=months.filter(m=>m.score>=25).map(m=>m.month);
  const factors=[{key:'humidity',label:'湿度贡献',detail:'湿度归一因子相对较低；提高湿度或降低起效阈值会减小评分折减。'},{key:'temperature',label:'温度修正',detail:'温度归一因子相对较低；低温或偏离 25°C 都会使本模型评分下降。'},...(metric==='technical'?[]:[{key:'solar',label:'辐照供能',detail:'辐照归一因子相对较低；供能指数越大，辐照不足满分时的折减越强。'}])];
  const limiting=factors.reduce((a,b)=>current[b.key]<current[a.key]?b:a);
  return {peak,favorable,limiting,months,current,grade:grade(current[metric]),baseline:evaluate(point,defaults,month)[metric],delta:current[metric]-evaluate(point,defaults,month)[metric]};
}

export function toCsv(rows){
  const cell=v=>{const s=String(v??'');return /[",\r\n]/.test(s)?'"'+s.replaceAll('"','""')+'"':s};
  return '\uFEFF'+rows.map(row=>row.map(cell).join(',')).join('\r\n');
}

export function assessmentCsv(rows,{weights,month,scope,start=2021,end=2025}){
  return toCsv([['分析范围','区域','采样城市','时间范围','相对湿度(%)','气温(°C)','太阳辐照(kWh/m²/day)','日均降水(mm/day)','综合推荐度','技术可行度','供能适宜性','湿度阈值(%)','光照指数','少雨权重'],...rows.map(p=>[scope,p.name,p.city,month?`${month}月(${start}—${end}多年均值)`:`${start}—${end}全年`,...['humidity','temperature','solar','precipitation'].map(k=>p.climate[k].toFixed(2)),...['combined','technical','economic'].map(k=>p[k].toFixed(2)),weights.humidityThreshold,weights.solarWeight,weights.droughtWeight])]);
}

const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function assessmentReport(rows,{weights,month,metric,scope,meta,createdAt=new Date()}){
  const period=month?`${month}月多年均值`:'全年均值';
  const fmt=n=>Number(n).toFixed(1);
  const selectedLabel=metricNames[metric];
  const leader=rows[0];
  const details=rows.map(p=>{const insight=describePoint(p,weights,metric,month);return `<tr><td>${escape(p.name)}<small>${escape(p.city)}采样点</small></td><td>${fmt(p[metric])}</td><td>${escape(grade(p[metric]))}</td><td>${fmt(p.climate.humidity)}%</td><td>${fmt(p.climate.temperature)}°C</td><td>${p.climate.solar.toFixed(2)}</td><td>${p.climate.precipitation.toFixed(2)}</td><td>${insight.peak.month}月</td></tr>`}).join('');
  const peaks=rows.slice(0,5).map(p=>{const a=describePoint(p,weights,metric,month);const points=a.months.map((m,i)=>`${30+i*50},${140-m.score*1.15}`).join(' ');return `<article><h3>${escape(p.name)} <span>${escape(p.city)}</span></h3><svg viewBox="0 0 610 180" role="img" aria-label="${escape(p.name)}月度评分"><path d="M30 25V140H580" fill="none" stroke="#ccd8dc"/><text x="6" y="30" font-size="10" fill="#526a73">100</text><text x="10" y="85" font-size="10" fill="#526a73">50</text><text x="15" y="142" font-size="10" fill="#526a73">0</text><polyline points="${points}" fill="none" stroke="#137b76" stroke-width="3"/>${a.months.map((m,i)=>`<text x="${30+i*50}" y="165" text-anchor="middle" font-size="11" fill="#526a73">${m.month}月</text>`).join('')}</svg><p>全年最佳月份：${a.peak.month}月（${fmt(a.peak.score)} 分）；评分 ≥25 的月份：${escape(a.favorable.length?a.favorable.join('、')+'月':'暂无')}。</p><p>相对较弱模型因子：${escape(a.limiting.label)}。${escape(a.limiting.detail)}</p></article>`}).join('');
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>凝水于空 · ${escape(scope)}分析报告</title><style>*{box-sizing:border-box}body{margin:0;background:#edf3f4;color:#18343e;font:14px/1.8 system-ui,"Microsoft YaHei",sans-serif}main{max-width:1100px;margin:40px auto;background:white;padding:48px}header{border-bottom:3px solid #147d75;padding-bottom:25px}h1{font-size:30px;margin:8px 0}h2{font-size:20px;margin:30px 0 15px}h3{margin:0}h3 span,small{color:#68828a;font-weight:400;font-size:12px}small{display:block}.tag{color:#147d75;letter-spacing:2px}.meta,.note{color:#5a727d}.summary{padding:20px;background:#e7f4ef;border-left:4px solid #147d75;margin:24px 0}table{border-collapse:collapse;width:100%;font-size:12px}th,td{text-align:left;border-bottom:1px solid #dee8eb;padding:12px 8px}th{background:#edf4f5;font-weight:500}.scroll{overflow-x:auto}.charts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}article{border:1px solid #d6e2e5;padding:18px}svg{width:100%;height:auto}article p{font-size:12px;margin:6px 0}button{background:#147d75;color:white;border:0;padding:12px 18px;cursor:pointer;border-radius:6px}.note{font-size:12px;border-top:1px solid #d7e4e8;padding-top:18px;margin-top:30px}@media(max-width:650px){main{margin:0;padding:24px}.charts{grid-template-columns:1fr}h1{font-size:24px}}@media print{body{background:white}main{margin:0;padding:0;max-width:none}button{display:none}article,tr{break-inside:avoid}thead{display:table-header-group}.scroll{overflow:visible}.note{font-size:10px}}</style></head><body><main><header><div class="tag">AIR WATER ATLAS / 分析报告</div><h1>${escape(scope)} · ${escape(selectedLabel)}</h1><div class="meta">气象期间 ${meta.start}—${meta.end} · ${escape(period)} · ${rows.length} 个采样点 · 生成于 ${escape(createdAt.toLocaleString('zh-CN'))}</div></header><div class="summary">${leader?`当前范围中，<strong>${escape(leader.name)}</strong>的${escape(selectedLabel)}最高，为 <strong>${fmt(leader[metric])} / 100</strong>。`:'当前未选择分析区域。'}<br>模型参数：湿度阈值 ${weights.humidityThreshold}% · 辐照指数 ${weights.solarWeight} · 少雨权重 ${weights.droughtWeight}。</div><button onclick="window.print()">打印 / 保存为 PDF</button><h2>当前范围的评估结果</h2><div class="scroll"><table><thead><tr><th>区域 / 采样点</th><th>${escape(selectedLabel)}</th><th>等级</th><th>湿度</th><th>气温</th><th>辐照<br>kWh/m²/day</th><th>降水<br>mm/day</th><th>全年最佳月</th></tr></thead><tbody>${details}</tbody></table></div><h2>月度窗口与影响因素${rows.length>5?' · 当前范围前五名':''}</h2><div class="charts">${peaks}</div><h2>评分口径</h2><p>技术可行度 = 100 × H × T；供能适宜性 = 技术可行度 × Sᵅ；综合推荐度 = 供能适宜性 × (1 + βD) / (1 + β)。全年得分为 12 个月得分的等权平均。</p><div class="note">来源：NASA POWER Monthly API，数据采集于 ${escape(meta.retrievedAt.slice(0,10))}。省份分析使用省会坐标采样；吉林市州使用独立点位。评分为未经装置实测校准的探索性指标，不代表实际产水量、成本或投资回报；供能适宜性只反映辐照代理，少雨权重不代表真实供水缺口。分级阈值：高 ≥40、较高 ≥25、中等 ≥12、低 &lt;12。</div></main></body></html>`;
}

export function downloadFile(content,filename,type){
  const url=URL.createObjectURL(new Blob([content],{type}));
  const a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
