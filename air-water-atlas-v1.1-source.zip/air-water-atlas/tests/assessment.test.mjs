import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { defaults, evaluate, scoreMonth } from '../src/model.js';
import { assessmentCsv, assessmentReport, describePoint, presets, sanitizePreferences, toCsv } from '../src/assessment.js';
const data=JSON.parse(readFileSync(new URL('../public/data/climate.json',import.meta.url)));
const context={weights:{...defaults},month:7,metric:'combined',scope:'所选省份对比',meta:data.meta};

test('comparison and city CSV exports contain only the rows in the current analysis',()=>{
  const selected=data.provinces.filter(p=>['220000','440000','530000'].includes(p.code)).map(p=>evaluate(p,defaults,7));
  const csv=assessmentCsv(selected,context);
  assert.equal(csv.trim().split('\r\n').length,4);
  assert.ok(csv.includes('7月(2021—2025多年均值)'));
  assert.ok(csv.includes('供能适宜性'));
  assert.ok(!csv.includes('北京'));
  const city=evaluate(data.cities[0],defaults,7);
  assert.equal(assessmentCsv([city],{...context,scope:'市州采样点'}).trim().split('\r\n').length,2);
  assert.ok(assessmentCsv([city],context).includes(city.name));
});
test('CSV retains commas, quotes and line breaks as a single quoted cell',()=>{
  assert.equal(toCsv([['区域,城市','说明"引用"','两行\n内容']]),'\uFEFF"区域,城市","说明""引用""","两行\n内容"');
});
test('best months and selected metric remain consistent with the actual monthly model',()=>{
  for(const p of [...data.provinces,...data.cities])for(const metric of ['combined','technical','economic']){
    const insight=describePoint(p,defaults,metric,7);
    assert.equal(insight.peak.score,Math.max(...p.months.map(m=>scoreMonth(m)[metric])));
    assert.equal(insight.current[metric],scoreMonth(p.months[6])[metric]);
    assert.equal(insight.delta,0);
    assert.ok(insight.favorable.every(month=>scoreMonth(p.months[month-1])[metric]>=25));
  }
});
test('saved preferences reject invalid values, deduplicate selections and bound model parameters',()=>{
  const result=sanitizePreferences({metric:'bad',month:13,selected:['220000','220000','bad','440000'],weights:{humidityThreshold:100,solarWeight:NaN,droughtWeight:-1}});
  assert.equal(result.metric,'combined');assert.equal(result.month,0);
  assert.deepEqual(result.selected,['220000','440000']);
  assert.deepEqual(result.weights,{humidityThreshold:60,solarWeight:1,droughtWeight:0});
  assert.deepEqual(sanitizePreferences(null).weights,defaults);
  assert.equal(sanitizePreferences({selected:[]}).selected.length,0);
});
test('parameter presets keep all sample scores finite and within the public score scale',()=>{
  for(const preset of presets)for(const p of data.provinces)for(const m of p.months){
    for(const value of Object.values(scoreMonth(m,preset.weights)))assert.ok(Number.isFinite(value)&&value>=0&&value<=100);
  }
});
test('offline report preserves its scope and parameters and escapes data as text',()=>{
  const p=evaluate({...data.provinces[0],name:'区域<script>alert(1)</script>'},defaults,7);
  const html=assessmentReport([p],{...context,createdAt:new Date('2026-10-05T00:00:00Z')});
  assert.ok(html.includes('所选省份对比'));
  assert.ok(html.includes('1 个采样点'));
  assert.ok(html.includes('少雨权重 0.35'));
  assert.ok(html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
  assert.ok(!html.includes('<script>alert(1)</script>'));
  assert.ok(html.includes('window.print()'));
  assert.ok(html.includes('<svg'));
  assert.ok(!html.includes('src="http'));
});
