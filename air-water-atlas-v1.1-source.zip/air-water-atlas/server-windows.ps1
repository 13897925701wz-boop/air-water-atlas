$ErrorActionPreference = 'Stop'
$port = 8765
$siteRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'dist'))
$index = Join-Path $siteRoot 'index.html'
if (-not [System.IO.File]::Exists($index)) {
    throw 'The dist folder is missing. Please use the complete Windows package.'
}

$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, $port)
try {
    $listener.Start()
} catch {
    Write-Host ('Cannot listen on port {0}: {1}' -f $port, $_.Exception.Message) -ForegroundColor Red
    exit 1
}

Write-Host ('Air Water Atlas is running at http://localhost:{0}/overview' -f $port) -ForegroundColor Cyan
Write-Host 'Keep this window open while viewing the site. Press Ctrl+C to stop.'
Write-Host 'On the same Wi-Fi, other computers can use this PC IPv4 address and port 8765.'
Write-Host 'If Windows Firewall asks, allow access on private networks.'
try { Start-Process ('http://localhost:{0}/overview' -f $port) } catch {}

function Send-Response([System.IO.Stream]$stream, [int]$status, [string]$reason, [string]$mime, [byte[]]$body, [bool]$headOnly) {
    $header = "HTTP/1.1 $status $reason`r`nContent-Type: $mime`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($bytes, 0, $bytes.Length)
    if (-not $headOnly -and $body.Length -gt 0) {
        $stream.Write($body, 0, $body.Length)
    }
    $stream.Flush()
}

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 10000
            $client.SendTimeout = 10000
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
            $requestLine = $reader.ReadLine()
            if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }
            do { $line = $reader.ReadLine() } while ($null -ne $line -and $line.Length -gt 0)
            $parts = $requestLine.Split(' ')
            if ($parts.Length -lt 2) { continue }
            $method = $parts[0]
            $headOnly = $method -eq 'HEAD'
            if ($method -ne 'GET' -and -not $headOnly) {
                Send-Response $stream 405 'Method Not Allowed' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Method not allowed')) $false
                continue
            }
            $urlPath = [System.Uri]::UnescapeDataString(($parts[1] -split '\?')[0])
            $relative = $urlPath.TrimStart([char[]]@('/'))
            if ($relative.Length -eq 0) { $relative = 'index.html' }
            $candidate = [System.IO.Path]::GetFullPath((Join-Path $siteRoot $relative))
            $prefix = $siteRoot + [System.IO.Path]::DirectorySeparatorChar
            if (-not $candidate.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
                Send-Response $stream 403 'Forbidden' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Forbidden')) $headOnly
                continue
            }
            if (-not [System.IO.File]::Exists($candidate)) {
                if ([System.IO.Path]::GetExtension($candidate).Length -eq 0) {
                    $candidate = $index
                } else {
                    Send-Response $stream 404 'Not Found' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Not found')) $headOnly
                    continue
                }
            }
            $extension = [System.IO.Path]::GetExtension($candidate).ToLowerInvariant()
            $mime = switch ($extension) {
                '.html' { 'text/html; charset=utf-8' }
                '.js' { 'text/javascript; charset=utf-8' }
                '.css' { 'text/css; charset=utf-8' }
                '.json' { 'application/json; charset=utf-8' }
                '.svg' { 'image/svg+xml' }
                '.png' { 'image/png' }
                '.jpg' { 'image/jpeg' }
                '.jpeg' { 'image/jpeg' }
                '.ico' { 'image/x-icon' }
                '.woff2' { 'font/woff2' }
                default { 'application/octet-stream' }
            }
            $body = [System.IO.File]::ReadAllBytes($candidate)
            Send-Response $stream 200 'OK' $mime $body $headOnly
        } catch {
            Write-Warning ('Request failed: {0}' -f $_.Exception.Message)
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
}
