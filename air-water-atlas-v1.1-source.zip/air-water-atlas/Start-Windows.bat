@echo off
setlocal
cd /d "%~dp0"
if not exist "dist\index.html" (
  echo Missing dist\index.html. Please use the complete Windows package.
  pause
  exit /b 1
)
set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS_EXE%" (
  echo Windows PowerShell was not found.
  pause
  exit /b 1
)
"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0server-windows.ps1"
if errorlevel 1 (
  echo.
  echo The site could not start. Check whether port 8765 is in use.
  pause
)
