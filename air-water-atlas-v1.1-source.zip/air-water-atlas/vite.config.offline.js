import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
export default defineConfig({
  plugins:[vue()],
  base:'./',
  build:{outDir:'dist-offline',cssCodeSplit:false,rollupOptions:{output:{inlineDynamicImports:true}}}
});
